export const mockPredictionData = [
  {
    id: '1',
    bank: 'HDFC Bank',
    usagePeriod: '2020-05',
    problemDescription: 'I have been facing issues with high transaction fees and poor customer service. The mobile app also crashes frequently.',
    churnRisk: 85,
    date: '2024-05-10T10:30:00Z',
    accountAge: '3-5 years',
    accountType: 'Savings Account',
    monthlyTransactions: '11-20',
    averageBalance: '₹50,000 - ₹1,00,000'
  },
  {
    id: '2',
    bank: 'State Bank of India (SBI)',
    usagePeriod: '2018-02',
    problemDescription: 'Long waiting times at the branch. Digital services are not user-friendly. Need better options.',
    churnRisk: 65,
    date: '2024-05-08T14:25:00Z',
    accountAge: '5-10 years',
    accountType: 'Current/Checking Account',
    monthlyTransactions: 'More than 30',
    averageBalance: '₹1,00,000 - ₹5,00,000'
  },
  {
    id: '3',
    bank: 'ICICI Bank',
    usagePeriod: '2022-09',
    problemDescription: 'I am generally satisfied with the services, but would like to see lower fees for international transactions.',
    churnRisk: 25,
    date: '2024-05-05T09:15:00Z',
    accountAge: '1-3 years',
    accountType: 'Salary Account',
    monthlyTransactions: '21-30',
    averageBalance: '₹10,000 - ₹50,000'
  },
  {
    id: '4',
    bank: 'Axis Bank',
    usagePeriod: '2021-11',
    problemDescription: 'ATM network is limited in my area. Need to travel far to find an ATM without surcharge.',
    churnRisk: 45,
    date: '2024-05-01T16:40:00Z',
    accountAge: '1-3 years',
    accountType: 'Savings Account',
    monthlyTransactions: '5-10',
    averageBalance: '₹10,000 - ₹50,000'
  },
  {
    id: '5',
    bank: 'Kotak Mahindra Bank',
    usagePeriod: '2023-06',
    problemDescription: 'Very satisfied with most services. Would recommend to friends and family.',
    churnRisk: 10,
    date: '2024-04-28T11:20:00Z',
    accountAge: 'Less than 6 months',
    accountType: 'Premium/Privilege Account',
    monthlyTransactions: '11-20',
    averageBalance: 'More than ₹5,00,000'
  }
];