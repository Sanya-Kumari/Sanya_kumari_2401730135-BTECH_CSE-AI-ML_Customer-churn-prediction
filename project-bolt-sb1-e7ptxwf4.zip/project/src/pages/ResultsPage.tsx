import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, AlertTriangle, Share2, Download, Info } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { mockPredictionData } from '../utils/mockData';
import LoadingSpinner from '../components/LoadingSpinner';

const ResultsPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');
  
  const [isLoading, setIsLoading] = useState(true);
  const [prediction, setPrediction] = useState<any>(null);

  useEffect(() => {
    document.title = 'Analysis Results - ChurnGuard';
    
    if (!id) {
      navigate('/dashboard');
      return;
    }
    
    // Get prediction data
    const fetchPrediction = () => {
      setIsLoading(true);
      
      // Try to get from localStorage first
      const storedPredictions = localStorage.getItem('predictions');
      const predictions = storedPredictions ? JSON.parse(storedPredictions) : [];
      
      const found = predictions.find((p: any) => p.id === id);
      
      if (found) {
        setPrediction(found);
      } else {
        // Use mock data as fallback
        const mockPrediction = mockPredictionData.find(p => p.id === id);
        if (mockPrediction) {
          setPrediction(mockPrediction);
        } else {
          toast.error('Prediction not found');
          navigate('/dashboard');
        }
      }
      
      setIsLoading(false);
    };
    
    fetchPrediction();
  }, [id, navigate]);

  if (isLoading) {
    return <LoadingSpinner fullScreen size="large" />;
  }

  if (!prediction) {
    return null;
  }

  const copyToClipboard = () => {
    const text = `
      Bank Churn Prediction Report
      ---------------------------
      Bank: ${prediction.bank}
      Usage Period: ${prediction.usagePeriod}
      Account Type: ${prediction.accountType || 'N/A'}
      Churn Risk: ${prediction.churnRisk}%
      Date: ${new Date(prediction.date).toLocaleDateString()}
      
      ${prediction.churnRisk >= 75 
        ? 'High risk of churn. Immediate action required.' 
        : prediction.churnRisk >= 30 
        ? 'Medium risk of churn. Monitor closely.' 
        : 'Low risk of churn. Maintain regular engagement.'}
    `;
    
    navigator.clipboard.writeText(text);
    toast.success('Report copied to clipboard');
  };

  const getRiskLevel = (riskPercentage: number) => {
    if (riskPercentage >= 75) return 'High Risk';
    if (riskPercentage >= 30) return 'Medium Risk';
    return 'Low Risk';
  };

  const getRiskColor = (riskPercentage: number) => {
    if (riskPercentage >= 75) return 'text-red-700 bg-red-100 ring-red-700/10';
    if (riskPercentage >= 30) return 'text-yellow-800 bg-yellow-100 ring-yellow-600/20';
    return 'text-green-700 bg-green-100 ring-green-600/20';
  };

  const getRecommendations = (riskPercentage: number) => {
    if (riskPercentage >= 75) {
      return [
        'Reach out immediately for a personalized retention offer',
        'Schedule a one-on-one meeting with a relationship manager',
        'Offer fee waivers or special rates on products',
        'Conduct a detailed review of account issues and resolve them',
        'Consider upgrading to premium services with enhanced benefits'
      ];
    }
    
    if (riskPercentage >= 30) {
      return [
        'Send a customer satisfaction survey',
        'Offer improved digital banking features',
        'Provide educational content about unused bank features',
        'Consider promotional offers for additional services',
        'Schedule a regular check-in call'
      ];
    }
    
    return [
      'Continue regular communication',
      'Share updates about new features and services',
      'Invite to loyalty programs or events',
      'Occasionally check satisfaction with current services',
      'Consider cross-selling appropriate products'
    ];
  };

  const getChurnFactors = (prediction: any) => {
    const factors = [];
    
    if (prediction.problems.toLowerCase().includes('fee') || 
        prediction.problems.toLowerCase().includes('charge') || 
        prediction.problems.toLowerCase().includes('expensive')) {
      factors.push('High fees or charges');
    }
    
    if (prediction.problems.toLowerCase().includes('service') || 
        prediction.problems.toLowerCase().includes('customer') || 
        prediction.problems.toLowerCase().includes('support')) {
      factors.push('Poor customer service');
    }
    
    if (prediction.problems.toLowerCase().includes('online') || 
        prediction.problems.toLowerCase().includes('app') || 
        prediction.problems.toLowerCase().includes('digital')) {
      factors.push('Online/mobile banking issues');
    }
    
    if (prediction.problems.toLowerCase().includes('branch') || 
        prediction.problems.toLowerCase().includes('atm') || 
        prediction.problems.toLowerCase().includes('location')) {
      factors.push('Branch/ATM accessibility');
    }
    
    // Add some generic factors
    if (factors.length < 2) {
      if (!factors.includes('High fees or charges') && prediction.churnRisk > 50) {
        factors.push('High fees or charges');
      }
      
      if (!factors.includes('Poor customer service') && prediction.churnRisk > 60) {
        factors.push('Poor customer service');
      }
      
      if (factors.length < 2) {
        factors.push('Competitive offers from other banks');
      }
    }
    
    return factors;
  };

  const exportPDF = () => {
    toast.success('Report downloaded successfully');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <button
        onClick={() => navigate('/dashboard')}
        className="flex items-center text-blue-700 hover:text-blue-900 mb-6"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Dashboard
      </button>
      
      <div className="flex flex-col md:flex-row justify-between items-start mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Churn Analysis Results</h1>
          <p className="text-gray-600">
            Analyzed on {new Date(prediction.date).toLocaleDateString()}
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex space-x-3">
          <button 
            onClick={copyToClipboard}
            className="btn bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 flex items-center"
          >
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </button>
          <button 
            onClick={exportPDF}
            className="btn bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 flex items-center"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Main Card */}
        <div className="lg:col-span-2">
          <div className="card space-y-6">
            {/* Risk Score */}
            <div className="flex flex-col items-center justify-center py-6">
              <h2 className="text-xl font-semibold mb-2">Customer Churn Risk</h2>
              
              <div className="relative w-48 h-48">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  {/* Background circle */}
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="10"
                  />
                  
                  {/* Foreground circle - risk percentage */}
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke={prediction.churnRisk >= 75 ? '#ef4444' : prediction.churnRisk >= 30 ? '#f59e0b' : '#10b981'}
                    strokeWidth="10"
                    strokeDasharray={`${2 * Math.PI * 45 * (prediction.churnRisk / 100)} ${2 * Math.PI * 45 * (1 - prediction.churnRisk / 100)}`}
                    strokeDashoffset={2 * Math.PI * 45 * 0.25}
                    transform="rotate(-90 50 50)"
                  />
                  
                  {/* Center text */}
                  <text
                    x="50"
                    y="50"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="20"
                    fontWeight="bold"
                    fill={prediction.churnRisk >= 75 ? '#b91c1c' : prediction.churnRisk >= 30 ? '#b45309' : '#047857'}
                  >
                    {prediction.churnRisk}%
                  </text>
                </svg>
              </div>
              
              <div className={`mt-4 inline-flex items-center rounded-md px-2.5 py-1.5 text-sm font-medium ring-1 ring-inset ${getRiskColor(prediction.churnRisk)}`}>
                {getRiskLevel(prediction.churnRisk)}
              </div>
            </div>
            
            {/* Customer Info */}
            <div>
              <h3 className="text-lg font-medium mb-3 pb-2 border-b border-gray-200">
                Customer Details
              </h3>
              <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Bank</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.bank}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Usage Duration</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.usageDuration}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Account Type</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.accountType || 'N/A'}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Account Age</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.accountAge || 'N/A'}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Transactions per Month</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.monthlyTransactions || 'N/A'}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Average Balance</dt>
                  <dd className="mt-1 text-sm text-gray-900">{prediction.averageBalance || 'N/A'}</dd>
                </div>
              </dl>
            </div>
            
            {/* Problem Description */}
            <div>
              <h3 className="text-lg font-medium mb-3">
                Reported Issues
              </h3>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {prediction.problemDescription}
              </p>
            </div>
          </div>
        </div>
        
        {/* Sidebar - Action Plan */}
        <div className="lg:col-span-1">
          <div className="card bg-blue-50 border border-blue-100">
            <h3 className="text-lg font-medium mb-4 text-blue-800">
              Retention Action Plan
            </h3>
            
            {prediction.churnRisk >= 50 && (
              <div className="bg-white p-4 rounded-md border border-red-200 mb-4 flex">
                <div className="mr-3 mt-0.5">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-red-700">High Priority</h4>
                  <p className="text-sm text-gray-600">
                    This customer needs immediate attention to prevent churn.
                  </p>
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">
                  Top Churn Factors
                </h4>
                <ul className="space-y-2">
                  {getChurnFactors(prediction).map((factor, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-700">
                      <span className="inline-block w-2 h-2 rounded-full bg-red-500 mr-2"></span>
                      {factor}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">
                  Recommended Actions
                </h4>
                <ul className="space-y-2">
                  {getRecommendations(prediction.churnRisk).map((recommendation, index) => (
                    <li key={index} className="flex items-start text-sm text-gray-700">
                      <span className="inline-block w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center mr-2 mt-0.5 text-xs font-medium">
                        {index + 1}
                      </span>
                      {recommendation}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-blue-200 flex items-start">
              <Info className="h-5 w-5 text-blue-700 mr-2 mt-0.5" />
              <p className="text-xs text-blue-700">
                Our AI prediction model is based on analysis of similar customer behavior patterns and historical data from over 50,000 banking customers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;