import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ArrowRight, BarChart2, Shield, TrendingUp } from 'lucide-react';

const HomePage = () => {
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    document.title = 'ChurnGuard - AI Bank Churn Prediction';
  }, []);

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="slide-up">
              <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-white leading-tight">
                Predict & Prevent <br />
                <span className="text-blue-200">Customer Churn</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8 max-w-lg">
                Use our AI-powered analysis to identify customers at risk of leaving your bank, and take action before it's too late.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                {isAuthenticated ? (
                  <Link to="/dashboard" className="btn-primary flex items-center justify-center">
                    Go to Dashboard
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                ) : (
                  <>
                    <Link to="/register" className="btn-primary flex items-center justify-center">
                      Get Started
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                    <Link to="/login" className="btn bg-white text-blue-700 hover:bg-blue-50 focus:ring-blue-500 flex items-center justify-center">
                      Sign In
                    </Link>
                  </>
                )}
              </div>
            </div>
            <div className="hidden lg:block">
              <img 
                src="https://images.pexels.com/photos/7054866/pexels-photo-7054866.jpeg" 
                alt="Banking professionals analyzing data" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How ChurnGuard Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our AI-powered platform analyzes customer data and banking patterns to identify high-risk customers before they leave.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card hover:shadow-lg group">
              <div className="rounded-full bg-blue-100 p-3 inline-block mb-4 group-hover:bg-blue-200 transition-colors">
                <BarChart2 className="h-6 w-6 text-blue-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Data Analysis</h3>
              <p className="text-gray-600">
                We analyze multiple data points including transaction history, account usage, and customer interactions.
              </p>
            </div>

            <div className="card hover:shadow-lg group">
              <div className="rounded-full bg-teal-100 p-3 inline-block mb-4 group-hover:bg-teal-200 transition-colors">
                <TrendingUp className="h-6 w-6 text-teal-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Predictive Models</h3>
              <p className="text-gray-600">
                Our advanced AI algorithms predict churn probability with high accuracy based on behavioral patterns.
              </p>
            </div>

            <div className="card hover:shadow-lg group">
              <div className="rounded-full bg-indigo-100 p-3 inline-block mb-4 group-hover:bg-indigo-200 transition-colors">
                <Shield className="h-6 w-6 text-indigo-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Preventive Actions</h3>
              <p className="text-gray-600">
                Get actionable insights and recommendations to retain at-risk customers before they decide to leave.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to reduce customer churn?</h2>
          <p className="text-gray-600 mb-8 text-lg">
            Join thousands of banks that have increased customer retention by up to 45% using our platform.
          </p>
          {!isAuthenticated && (
            <Link to="/register" className="btn-primary text-lg px-8 py-3">
              Start Your Free Trial
            </Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;