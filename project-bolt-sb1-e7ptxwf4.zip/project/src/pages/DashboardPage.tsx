import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  BarChart, PieChart, TrendingUp, AlertTriangle, Plus, FileText, 
  RefreshCcw, Download, Filter 
} from 'lucide-react';
import { mockPredictionData } from '../utils/mockData';

const DashboardPage = () => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [predictionData, setPredictionData] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    document.title = 'Dashboard - ChurnGuard';
    
    // Simulate loading data
    const timer = setTimeout(() => {
      setPredictionData(mockPredictionData);
      setIsLoading(false);
    }, 1200);
    
    return () => clearTimeout(timer);
  }, []);

  const filteredData = filter === 'all' 
    ? predictionData 
    : predictionData.filter(item => {
        if (filter === 'high-risk') return item.churnRisk >= 75;
        if (filter === 'medium-risk') return item.churnRisk >= 30 && item.churnRisk < 75;
        if (filter === 'low-risk') return item.churnRisk < 30;
        return true;
      });

  const highRiskCount = predictionData.filter(item => item.churnRisk >= 75).length;
  const mediumRiskCount = predictionData.filter(item => item.churnRisk >= 30 && item.churnRisk < 75).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user?.name}</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Link to="/problem-form" className="btn-primary flex items-center">
            <Plus className="h-4 w-4 mr-2" />
            New Analysis
          </Link>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-blue-700">Total Analyses</p>
              <h3 className="text-3xl font-bold text-gray-900 mt-2">
                {isLoading ? '-' : predictionData.length}
              </h3>
            </div>
            <div className="rounded-full bg-blue-200 p-2">
              <FileText className="h-5 w-5 text-blue-700" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <RefreshCcw className="h-3 w-3 text-blue-700 mr-1" />
            <span className="text-blue-700">Updated just now</span>
          </div>
        </div>
        
        <div className="card bg-gradient-to-br from-red-50 to-red-100 border border-red-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-red-700">High Risk Customers</p>
              <h3 className="text-3xl font-bold text-gray-900 mt-2">
                {isLoading ? '-' : highRiskCount}
              </h3>
            </div>
            <div className="rounded-full bg-red-200 p-2">
              <AlertTriangle className="h-5 w-5 text-red-700" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <div className="text-red-700 font-medium flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              {isLoading ? '-' : Math.round((highRiskCount / predictionData.length) * 100)}% of total
            </div>
          </div>
        </div>
        
        <div className="card bg-gradient-to-br from-yellow-50 to-yellow-100 border border-yellow-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-yellow-700">Medium Risk Customers</p>
              <h3 className="text-3xl font-bold text-gray-900 mt-2">
                {isLoading ? '-' : mediumRiskCount}
              </h3>
            </div>
            <div className="rounded-full bg-yellow-200 p-2">
              <PieChart className="h-5 w-5 text-yellow-700" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <div className="text-yellow-700 font-medium flex items-center">
              <BarChart className="h-3 w-3 mr-1" />
              {isLoading ? '-' : Math.round((mediumRiskCount / predictionData.length) * 100)}% of total
            </div>
          </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="card">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-3 md:mb-0">
            Recent Predictions
          </h2>
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 w-full md:w-auto">
            <div className="relative">
              <Filter className="h-4 w-4 text-gray-500 absolute top-2.5 left-3" />
              <select
                className="pl-9 pr-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-sm"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="all">All Risks</option>
                <option value="high-risk">High Risk</option>
                <option value="medium-risk">Medium Risk</option>
                <option value="low-risk">Low Risk</option>
              </select>
            </div>
            <button className="btn border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 flex items-center text-sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-pulse flex flex-col items-center">
              <div className="rounded-full bg-gray-200 h-12 w-12 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-24 mb-2.5"></div>
              <div className="h-4 bg-gray-200 rounded w-32"></div>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bank
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Usage Period
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Problem Description
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Churn Risk
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredData.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{item.bank}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{item.usagePeriod}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900 max-w-xs truncate">{item.problemDescription}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        item.churnRisk >= 75
                          ? 'bg-red-100 text-red-800'
                          : item.churnRisk >= 30
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {item.churnRisk}%
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(item.date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Link to={`/results?id=${item.id}`} className="text-blue-700 hover:text-blue-900">
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredData.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-sm">No prediction data found</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;