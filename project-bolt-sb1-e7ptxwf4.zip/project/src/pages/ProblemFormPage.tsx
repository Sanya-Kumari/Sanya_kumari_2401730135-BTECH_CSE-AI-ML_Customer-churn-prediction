import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { ArrowLeft, Loader, Check } from 'lucide-react';
import { mockPredictionData } from '../utils/mockData';

const ProblemFormPage = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    bankName: '',
    usageDuration: '',
    problems: '',
    contactPhone: '',
    contactEmail: '',
    accountAge: '',
    accountType: '',
    monthlyTransactions: '',
    averageBalance: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    document.title = 'New Analysis - ChurnGuard';
  }, []);

  const validateStep = (step: number) => {
    const newErrors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.bankName) {
        newErrors.bankName = 'Bank name is required';
      }
      if (!formData.usageDuration) {
        newErrors.usageDuration = 'Usage duration is required';
      }
      if (!formData.problems) {
        newErrors.problems = 'Problem description is required';
      }
    }

    if (step === 2) {
      if (!formData.accountAge) {
        newErrors.accountAge = 'Account age is required';
      }
      if (!formData.accountType) {
        newErrors.accountType = 'Account type is required';
      }
      if (!formData.monthlyTransactions) {
        newErrors.monthlyTransactions = 'Monthly transactions is required';
      }
      if (!formData.averageBalance) {
        newErrors.averageBalance = 'Average balance is required';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStep(currentStep)) return;
    
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a random ID for the new analysis
      const newId = crypto.randomUUID();
      
      // Store in localStorage
      const storedPredictions = localStorage.getItem('predictions');
      const predictions = storedPredictions ? JSON.parse(storedPredictions) : [];
      
      const newPrediction = {
        id: newId,
        bank: formData.bankName,
        usagePeriod: formData.usageDuration,
        problemDescription: formData.problems,
        churnRisk: Math.floor(Math.random() * 100),
        date: new Date().toISOString(),
        accountAge: formData.accountAge,
        accountType: formData.accountType,
        monthlyTransactions: formData.monthlyTransactions,
        averageBalance: formData.averageBalance,
        contactEmail: formData.contactEmail,
        contactPhone: formData.contactPhone
      };
      
      predictions.push(newPrediction);
      localStorage.setItem('predictions', JSON.stringify(predictions));
      
      toast.success('Analysis submitted successfully!');
      navigate(`/results?id=${newId}`);
    } catch (error) {
      toast.error('Failed to submit the analysis');
    } finally {
      setIsSubmitting(false);
    }
  };

  const banks = [
    'State Bank of India (SBI)',
    'HDFC Bank',
    'ICICI Bank',
    'Punjab National Bank (PNB)',
    'Bank of Baroda',
    'Canara Bank',
    'Axis Bank',
    'Union Bank of India',
    'IndusInd Bank',
    'Yes Bank',
    'Kotak Mahindra Bank',
    'Bank of India',
    'Central Bank of India',
    'Indian Bank',
    'UCO Bank',
    'Punjab & Sind Bank',
    'IDBI Bank',
    'Federal Bank',
    'South Indian Bank',
    'RBL Bank',
    'City Union Bank',
    'Karur Vysya Bank',
    'Bandhan Bank',
    'Jammu & Kashmir Bank',
    'Others'
  ];

  const accountTypes = [
    'Savings Account',
    'Current/Checking Account',
    'Fixed Deposit',
    'Recurring Deposit',
    'Salary Account',
    'Student Account',
    'Joint Account',
    'Senior Citizen Account',
    'NRI Account',
    'Premium/Privilege Account',
    'Others'
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <button
        onClick={() => navigate('/dashboard')}
        className="flex items-center text-blue-700 hover:text-blue-900 mb-6"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Dashboard
      </button>
      
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">New Churn Analysis</h1>
        <p className="text-gray-600">
          {currentStep === 1 ? 
            'Tell us about your banking experience and issues' : 
            'Additional details for better prediction accuracy'
          }
        </p>
      </div>
      
      {/* Progress Steps */}
      <div className="flex items-center mb-8">
        <div className="flex items-center relative">
          <div className={`rounded-full h-8 w-8 flex items-center justify-center ${
            currentStep >= 1 ? 'bg-blue-700 text-white' : 'bg-gray-200 text-gray-500'
          }`}>
            {currentStep > 1 ? <Check className="h-5 w-5" /> : 1}
          </div>
          <span className="ml-2 text-sm font-medium text-gray-500">Basic Info</span>
        </div>
        <div className={`flex-grow h-0.5 mx-4 ${currentStep >= 2 ? 'bg-blue-700' : 'bg-gray-200'}`}></div>
        <div className="flex items-center relative">
          <div className={`rounded-full h-8 w-8 flex items-center justify-center ${
            currentStep >= 2 ? 'bg-blue-700 text-white' : 'bg-gray-200 text-gray-500'
          }`}>
            {currentStep > 2 ? <Check className="h-5 w-5" /> : 2}
          </div>
          <span className="ml-2 text-sm font-medium text-gray-500">Account Details</span>
        </div>
        <div className={`flex-grow h-0.5 mx-4 ${currentStep >= 3 ? 'bg-blue-700' : 'bg-gray-200'}`}></div>
        <div className="flex items-center relative">
          <div className={`rounded-full h-8 w-8 flex items-center justify-center ${
            currentStep >= 3 ? 'bg-blue-700 text-white' : 'bg-gray-200 text-gray-500'
          }`}>
            3
          </div>
          <span className="ml-2 text-sm font-medium text-gray-500">Confirm</span>
        </div>
      </div>
      
      <div className="card slide-up">
        <form onSubmit={handleSubmit} className="space-y-6">
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="form-group">
                <label htmlFor="bankName" className="form-label">
                  Which bank are you using?
                </label>
                <select
                  id="bankName"
                  name="bankName"
                  value={formData.bankName}
                  onChange={handleChange}
                  className={`input-field ${errors.bankName ? 'border-red-500' : ''}`}
                  required
                >
                  <option value="" disabled>Select your bank</option>
                  {banks.map((bank, index) => (
                    <option key={index} value={bank}>{bank}</option>
                  ))}
                </select>
                {errors.bankName && <p className="form-error">{errors.bankName}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="usageDuration" className="form-label">
                  Since when are you using it?
                </label>
                <input
                  type="month"
                  id="usageDuration"
                  name="usageDuration"
                  value={formData.usageDuration}
                  onChange={handleChange}
                  className={`input-field ${errors.usageDuration ? 'border-red-500' : ''}`}
                  required
                />
                {errors.usageDuration && <p className="form-error">{errors.usageDuration}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="problems" className="form-label">
                  What problems are you facing?
                </label>
                <textarea
                  id="problems"
                  name="problems"
                  value={formData.problems}
                  onChange={handleChange}
                  rows={4}
                  className={`input-field ${errors.problems ? 'border-red-500' : ''}`}
                  placeholder="Describe the issues you have encountered"
                  required
                />
                {errors.problems && <p className="form-error">{errors.problems}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="contactPhone" className="form-label">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="contactPhone"
                  name="contactPhone"
                  value={formData.contactPhone}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="+91 98765 43210"
                  pattern="^\+?[0-9\s\-]{7,15}$"
                />
                <p className="text-sm text-gray-500 mt-1">Optional</p>
              </div>
              
              <div className="form-group">
                <label htmlFor="contactEmail" className="form-label">
                  Email ID
                </label>
                <input
                  type="email"
                  id="contactEmail"
                  name="contactEmail"
                  value={formData.contactEmail}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="you@example.com"
                />
                <p className="text-sm text-gray-500 mt-1">Optional</p>
              </div>
            </div>
          )}
          
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="form-group">
                <label htmlFor="accountAge" className="form-label">
                  How old is your account?
                </label>
                <select
                  id="accountAge"
                  name="accountAge"
                  value={formData.accountAge}
                  onChange={handleChange}
                  className={`input-field ${errors.accountAge ? 'border-red-500' : ''}`}
                  required
                >
                  <option value="" disabled>Select account age</option>
                  <option value="Less than 6 months">Less than 6 months</option>
                  <option value="6-12 months">6-12 months</option>
                  <option value="1-3 years">1-3 years</option>
                  <option value="3-5 years">3-5 years</option>
                  <option value="5-10 years">5-10 years</option>
                  <option value="More than 10 years">More than 10 years</option>
                </select>
                {errors.accountAge && <p className="form-error">{errors.accountAge}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="accountType" className="form-label">
                  What type of account do you have?
                </label>
                <select
                  id="accountType"
                  name="accountType"
                  value={formData.accountType}
                  onChange={handleChange}
                  className={`input-field ${errors.accountType ? 'border-red-500' : ''}`}
                  required
                >
                  <option value="" disabled>Select account type</option>
                  {accountTypes.map((type, index) => (
                    <option key={index} value={type}>{type}</option>
                  ))}
                </select>
                {errors.accountType && <p className="form-error">{errors.accountType}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="monthlyTransactions" className="form-label">
                  How many transactions do you make per month (approximately)?
                </label>
                <select
                  id="monthlyTransactions"
                  name="monthlyTransactions"
                  value={formData.monthlyTransactions}
                  onChange={handleChange}
                  className={`input-field ${errors.monthlyTransactions ? 'border-red-500' : ''}`}
                  required
                >
                  <option value="" disabled>Select transaction frequency</option>
                  <option value="Less than 5">Less than 5</option>
                  <option value="5-10">5-10</option>
                  <option value="11-20">11-20</option>
                  <option value="21-30">21-30</option>
                  <option value="More than 30">More than 30</option>
                </select>
                {errors.monthlyTransactions && <p className="form-error">{errors.monthlyTransactions}</p>}
              </div>
              
              <div className="form-group">
                <label htmlFor="averageBalance" className="form-label">
                  What is your average monthly balance range?
                </label>
                <select
                  id="averageBalance"
                  name="averageBalance"
                  value={formData.averageBalance}
                  onChange={handleChange}
                  className={`input-field ${errors.averageBalance ? 'border-red-500' : ''}`}
                  required
                >
                  <option value="" disabled>Select balance range</option>
                  <option value="Less than ₹10,000">Less than ₹10,000</option>
                  <option value="₹10,000 - ₹50,000">₹10,000 - ₹50,000</option>
                  <option value="₹50,000 - ₹1,00,000">₹50,000 - ₹1,00,000</option>
                  <option value="₹1,00,000 - ₹5,00,000">₹1,00,000 - ₹5,00,000</option>
                  <option value="More than ₹5,00,000">More than ₹5,00,000</option>
                </select>
                {errors.averageBalance && <p className="form-error">{errors.averageBalance}</p>}
              </div>
            </div>
          )}
          
          {currentStep === 3 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Review Your Information</h3>
              
              <div className="bg-gray-50 p-4 rounded-md">
                <dl className="divide-y divide-gray-200">
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Bank</dt>
                    <dd className="text-sm text-gray-900">{formData.bankName}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Usage Duration</dt>
                    <dd className="text-sm text-gray-900">{formData.usageDuration}</dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-sm font-medium text-gray-500 mb-1">Problems</dt>
                    <dd className="text-sm text-gray-900">{formData.problems}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Account Age</dt>
                    <dd className="text-sm text-gray-900">{formData.accountAge}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Account Type</dt>
                    <dd className="text-sm text-gray-900">{formData.accountType}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Monthly Transactions</dt>
                    <dd className="text-sm text-gray-900">{formData.monthlyTransactions}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Average Balance</dt>
                    <dd className="text-sm text-gray-900">{formData.averageBalance}</dd>
                  </div>
                  {formData.contactPhone && (
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Phone Number</dt>
                      <dd className="text-sm text-gray-900">{formData.contactPhone}</dd>
                    </div>
                  )}
                  {formData.contactEmail && (
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Email</dt>
                      <dd className="text-sm text-gray-900">{formData.contactEmail}</dd>
                    </div>
                  )}
                </dl>
              </div>
              
              <p className="text-sm text-gray-600">
                By submitting this form, you agree to our <a href="#" className="text-blue-700 hover:underline">Terms of Service</a> and <a href="#" className="text-blue-700 hover:underline">Privacy Policy</a>.
              </p>
            </div>
          )}
          
          <div className="flex justify-between mt-8">
            {currentStep > 1 && (
              <button
                type="button"
                onClick={prevStep}
                className="btn bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Previous
              </button>
            )}
            {currentStep < 3 ? (
              <button
                type="button"
                onClick={nextStep}
                className="btn-primary ml-auto"
              >
                Next
              </button>
            ) : (
              <button
                type="submit"
                className="btn-primary ml-auto flex items-center"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader className="h-4 w-4 animate-spin mr-2" />
                    Analyzing...
                  </>
                ) : "Submit Analysis"}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProblemFormPage;