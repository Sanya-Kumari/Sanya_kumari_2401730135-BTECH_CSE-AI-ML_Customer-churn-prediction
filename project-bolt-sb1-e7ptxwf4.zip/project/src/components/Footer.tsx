import { Ban as Bank, Github, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-100 py-6 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center space-x-2">
              <Bank className="h-6 w-6 text-blue-700" />
              <span className="font-semibold text-lg text-gray-900">ChurnGuard</span>
            </div>
            <p className="text-sm text-gray-600 mt-1">
              AI-powered bank churn prediction
            </p>
          </div>
          
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-gray-700 transition-colors">
              <Github className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-700 transition-colors">
              <Twitter className="h-5 w-5" />
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-600">
            © {new Date().getFullYear()} ChurnGuard. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-sm text-gray-600 hover:text-blue-700">
              Privacy Policy
            </a>
            <a href="#" className="text-sm text-gray-600 hover:text-blue-700">
              Terms of Service
            </a>
            <a href="#" className="text-sm text-gray-600 hover:text-blue-700">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;