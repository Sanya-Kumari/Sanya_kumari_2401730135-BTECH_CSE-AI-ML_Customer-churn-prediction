import { RotateCw } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  fullScreen?: boolean;
}

const LoadingSpinner = ({ 
  size = 'medium', 
  fullScreen = false 
}: LoadingSpinnerProps) => {
  const sizeClasses = {
    small: 'h-4 w-4',
    medium: 'h-8 w-8',
    large: 'h-12 w-12'
  };

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-gray-50/80 flex items-center justify-center z-50">
        <RotateCw 
          className={`${sizeClasses[size]} text-blue-700 animate-spin`}
        />
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center p-4">
      <RotateCw 
        className={`${sizeClasses[size]} text-blue-700 animate-spin`}
      />
    </div>
  );
};

export default LoadingSpinner;